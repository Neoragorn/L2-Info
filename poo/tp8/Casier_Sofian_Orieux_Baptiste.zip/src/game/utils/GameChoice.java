package game.utils;

/**
* Enumeration des differents coups possibles
*/
public enum GameChoice
{
	ROCK,
	PAPER,
	SCISSORS;
}