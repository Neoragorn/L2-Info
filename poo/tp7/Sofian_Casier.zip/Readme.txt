Casier Sofian
TP7 Image POO

Tp entièrement fonctionnel.

Pour compiler, se placer sur le dossier src et taper les commandes :
javac image/*.java -d ../classes
javac image/color/*.java -d ../classes

Pour l'executer, se placer sur le dossier racine et taper la commande :
java -classpath classes image.ImageMain /images/*Nomdelimage* x y
(avec x > 0 et y > 0)
