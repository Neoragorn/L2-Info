package battleship;

public enum Answer
{
	MISSED, 
	HIT, 
	SUNK;
}