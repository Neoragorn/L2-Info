TP6 Battleship
Rendu fait par Casier Sofian
Groupe 2 licence INFO

TP normalement entierement fonctionnel.

Se placer dans le repertoire src et taper la commande :
Pour compiler : javac battleship/*.java
Pour executer : java battleship.GameMain

Pour les tests, se placer dans le dossier racine et taper :

Pour compiler : javac -classpath test-1.7.jar test/NomdeClasseTest.java

Pour executer : java -jar test-1.7.jar NomDeClasseTest

