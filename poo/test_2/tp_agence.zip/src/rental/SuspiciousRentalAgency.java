package rental;

import java.util.*;

public class SuspiciousRentalAgency extends RentalAgency {
	public SuspiciousRentalAgency() {
		super();
	}
	public float rentVehicule(Client client, Vehicle v) 
	{
		if (client.getAge() < 25) {
		float res = (float)(super.rentVehicule(client,v));
		float res2 =  (float)(0.1 * res);
		return res+res2;
		}
		else {
			return super.rentVehicule(client,v);
		}
	}
}