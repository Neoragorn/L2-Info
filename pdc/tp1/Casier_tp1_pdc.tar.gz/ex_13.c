//exo 13

int	main()
{
  return (7);
}

/* Lorsque l'on retourne 256, la valeur 0 est renvoyé dans le bash. */
