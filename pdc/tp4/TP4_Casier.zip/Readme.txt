Casier Sofian
Orieux Baptiste
Groupe 2 Info
TP PdC

Exo 28 à exo 32.
Le fichier ex_29.c rassemble les exercices 29 à 32.
