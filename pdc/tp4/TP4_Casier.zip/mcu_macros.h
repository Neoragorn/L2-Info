#define MAXLINE  300
#define LINETOOLONG 2
/*#ifndef MCU_MACROS_H_
# define MCU_MACROS_H_



#endif /* MCU_MACROS_H_ */ 