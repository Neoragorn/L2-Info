
extern int readl(int line[]);

