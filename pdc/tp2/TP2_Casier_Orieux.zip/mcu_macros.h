#define MAXLINE  81
#define LINETOOLONG 2









