TP PdC
Casier Sofian
Orieux Baptiste
exercices 18 a 22
