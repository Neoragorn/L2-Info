TP3 PdC
Casier Sofian
Orieux Baptiste

Exercices 23 à 27