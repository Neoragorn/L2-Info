

void * monmalloc(unsigned int) ;
