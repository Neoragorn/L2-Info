Casier Sofian
Orieux Baptiste
TP2 ASD

Tri Rapide

Question 1)

Comme autre exemple de tri sur place, il y a par exemple le tri par insertion
ou le tri à bulle


Question 5)

Le tri rapide utilise normalement un tableau de longueur n et donc utilisera n espaces mémoires, rien de plus.

Question 10)

test 1)
Moyenne normal : 279
Moyenne Aleatoire : 281

test 2)
Moyenne normal : 282
Moyenne Aleatoire : 280

Après plusieurs tests, on se rend compte que le coût de comparaison 
des deux méthodes est très proche.

Question 11)


Question 12)

Normalement, la meilleur valeur a choisir en tant que pivot est la valeur médiane du tableau

Question 14)

Moyenne normal: 275
Moyenne Aleatoire: 276
Moyenne Opti comparaison minimum: 49

Question 15) voir fichier courbe.dat
L'algorithme du pivot optimal montre des problèmes dans sa conception, je ne suis pas sûr du nombre de comparaisons réels mais il est sûr qu'il est plus efficace que les deux autres methodes.

Question 17)

Moyenne normal: 282
Moyenne Aleatoire: 285
Moyenne Opti comparaison minimum: 49
Moyenne Opti: 823

On peut voir qu'en ajoutant les comparaisons faites par la recherche du pivot,
l'algorithme n'est plus du tout aussi efficace avec un nombre de comparaisons qui explose litteralement.


