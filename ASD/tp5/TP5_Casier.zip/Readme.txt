Casier Sofian
Licence 2 Info
TP Arbre binaire

Question 7) Le temps pris pour le calcul des valeurs est bien plus important.

Question 9) Le calcul est quasiment instantané, contairement à la méthode recursive.

Question 11)Lorsque l'on imprime l'arbre de maniere infixée, si il s'agit d'un arbre binaire de recherche, alors l'affichage sera croissant.

Question 15)

La recherche la moins importante du chiffre 0 se trouve dans l'ABR 3 avec 3 comparaisons.
Cela s'explique par le fait que 1 suit directement le 7 dans l'ABR 3.
Il y a donc une premiere comparaison avec 7, puis l'on passe au fils gauche, soit 1. Une deuxieme comparaison est faite ici et une derniere comparaison est faite pour verifier si il y a un noeud pouvant contenir le 0, ce qui n'est pas le cas, l'algorithme s'arrête là.

Question 16)

L'élément minimal sera dans le fils le plus à gauche et l'élément maximal sera dans le fils le plus à droite.