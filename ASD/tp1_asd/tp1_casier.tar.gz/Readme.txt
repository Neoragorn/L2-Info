Casier Sofian

Question 2)

Il faut compter le nombre d'opération de comparaison que le programme doit faire à chaque fois que l'on passe à un nouveau marqueur pour vérifier si il est positif ou non
Ce serait donc : Op * Nombre de marqueurs * nombres de marqueurs positifs

question 3)
Le pire des cas devrait être si il n'y a aucun élément négatif dans le tableau des marqueurs.

Question 6)
Le pire des cas pour cet algo serait si le tableau des marqueurs à tester est dans l'ordre décroissant

question 10)

m = 10 p = 5 pour la stratégie 1

m = 10 p = 10 pour la strategie 2

La stratégie 1 semble le plus souvent être la méthode la plus rapide pour avoir un résultat, avec des comparaisons bien moins importantes.
La stratégie 2 est plus adaptée lorsque le nombre de marqueurs et le nombre de marqueurs positifs sont proches.
Je n'ai pas réussi a trouver de cas adapté à la stratégie 3.

Question  13)

Nous pouvons voir, via les graphiques, que la stratégie 1 est constamment croissante.
Plus le nombre de marqueurs est important, plus le nombre de comparaisons seront importantes jusqu'à atteindre une limite.
La stratégie 3 est plus utile sur de grands nombres, nous pouvons voir au fur et à mesure qu'elle
varie beaucoup avec le nombre de marqueurs.