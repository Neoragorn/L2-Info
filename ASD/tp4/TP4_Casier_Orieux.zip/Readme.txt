Casier Sofian
Orieux Baptiste
TP4 ASD

Question 4)

Avec une taille de 1 au niveau du filtre, on arrive à avoir un faux positif
sur le mot tiré au hasard

Question 7)

On remarque par ce graphique que plus la taille du filtre augmente, plus le nombre de faux positifs diminue rapidement.  Cela se ressent encore plus lorsque le pourcentage de faux positifs est plus élevé au départ.
